import discord
from discord.ext import commands
import os

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(
    command_prefix="!",
    intents=intents
)

@bot.event
async def on_ready():
    print(f"Bot online: {bot.user}")
    print(f"ID: {bot.user.id}")

@bot.command()
async def ping(ctx):
    await ctx.send(f"Pong! 🏓 {round(bot.latency * 1000)}ms")

bot.run("MTU0ODQ3MjQ3MTQ0NTk3MTA5Ng.G8WsqH.1loWCjQY2LaBUzi0Pk5aBHrN-HTARYHoN35UH4")